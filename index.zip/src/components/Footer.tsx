import { Link } from "wouter";
import { Info, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-muted/30 border-t mt-16">
      <div className="border-t-4 border-primary bg-muted/50 py-6">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
            <div className="text-sm leading-relaxed text-muted-foreground">
              <p className="font-semibold text-foreground mb-2">Important Disclaimer</p>
              <p>
                TenderWin India is an independent tender consulting and facilitation service. We are not affiliated, associated, authorized, endorsed by, or in any way officially connected with the Central Public Procurement Portal (CPPP/eProcure), GeM, or any Central or State Government entity or PSU. All bid submissions are the ultimate responsibility of the client.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
          <div>
            <h3 className="text-lg font-semibold mb-4 text-foreground">Navigation</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" data-testid="link-footer-home">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/services" data-testid="link-footer-services">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Services</span>
                </Link>
              </li>
              <li>
                <Link href="/tender-alerts" data-testid="link-footer-tender-alerts">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Tender Alerts</span>
                </Link>
              </li>
              <li>
                <Link href="/case-studies" data-testid="link-footer-case-studies">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Case Studies</span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-foreground">Services</h3>
            <ul className="space-y-3">
              <li className="text-sm text-muted-foreground">Document Review & Filing</li>
              <li className="text-sm text-muted-foreground">Proposal Writing & Strategy</li>
              <li className="text-sm text-muted-foreground">Daily Tender Alerts</li>
              <li className="text-sm text-muted-foreground">Compliance Consulting</li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-foreground">Legal</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/disclaimer" data-testid="link-footer-disclaimer">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Disclaimer</span>
                </Link>
              </li>
              <li>
                <Link href="/terms" data-testid="link-footer-terms">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Terms of Service</span>
                </Link>
              </li>
              <li>
                <Link href="/privacy" data-testid="link-footer-privacy">
                  <span className="text-sm text-muted-foreground hover:text-primary transition-colors">Privacy Policy</span>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4 text-foreground">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Mail className="h-4 w-4" />
                <span data-testid="text-contact-email">info@tenderwin.in</span>
              </li>
              <li className="flex items-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <span data-testid="text-contact-phone">+91 98765 43210</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-muted-foreground">
                <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                <span data-testid="text-contact-address">Mumbai, Maharashtra, India</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-12 pt-8 text-center">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} TenderWin India. All rights reserved. | Professional Tender Facilitation Services
          </p>
        </div>
      </div>
    </footer>
  );
}
