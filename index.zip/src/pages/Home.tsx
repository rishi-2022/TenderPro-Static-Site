import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, FileCheck, Award, Clock, AlertCircle, TrendingUp, Bell } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen">
      <section className="relative min-h-[600px] lg:min-h-[700px] flex items-center justify-center overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-primary/80">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=1600')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-primary/90 to-transparent" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-5xl lg:text-6xl font-bold text-white mb-6 tracking-tight" data-testid="text-hero-headline">
            We Don't Just Find Tenders.<br />We Prepare Winning Bids.
          </h1>
          <p className="text-xl lg:text-2xl text-white/90 mb-8 max-w-3xl mx-auto font-medium" data-testid="text-hero-subheadline">
            Your Expert Partner for 100% Compliant EOI & Tender Submissions in India
          </p>
          <Link href="/contact" data-testid="link-hero-cta">
            <Button size="lg" className="bg-gold text-gold-foreground text-lg px-8 py-6 h-auto shadow-lg" data-testid="button-hero-cta">
              Book Your FREE Bid Assessment
            </Button>
          </Link>
        </div>
      </section>

      <section className="py-16 lg:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-semibold mb-4 text-foreground">Why Businesses Choose Us</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Stop losing opportunities due to technical rejections and compliance issues
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <AlertCircle className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Avoid Technical Rejection</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  85% of first-time bidders face rejection due to missing documents or incorrect formats. We ensure 100% compliance.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <FileCheck className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Meet Complex Requirements</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Navigate CPPP, GeM, and PSU portals with expert guidance on digital signatures, EMD, and bid securities.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-primary/10 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Save Countless Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Focus on your business while we handle the complex documentation and submission process for you.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-semibold mb-4 text-foreground">Our Consulting Services</h2>
            <p className="text-lg text-muted-foreground">
              Choose the right level of support for your tender needs
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
            <Card className="hover-elevate">
              <CardHeader>
                <Badge className="w-fit mb-2 bg-primary text-primary-foreground">Tier 1</Badge>
                <CardTitle className="text-2xl">Document Review & Filing</CardTitle>
                <CardDescription className="text-lg font-semibold text-gold">₹15,000 - ₹25,000</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="font-semibold text-primary">Compliance Guarantee</p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Complete document organization and verification</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Eligibility cross-check against tender requirements</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Digital signature integration guidance</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Complete CPPP/GeM portal upload support</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/services" className="w-full" data-testid="link-tier1-details">
                  <Button variant="outline" className="w-full" data-testid="button-tier1-learn-more">Learn More</Button>
                </Link>
              </CardFooter>
            </Card>

            <Card className="border-2 border-gold hover-elevate relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-gold text-gold-foreground px-4 py-1 text-xs font-semibold">
                RECOMMENDED
              </div>
              <CardHeader className="pt-8">
                <Badge className="w-fit mb-2 bg-gold text-gold-foreground">Tier 2</Badge>
                <CardTitle className="text-2xl">Proposal Writing & Strategy</CardTitle>
                <CardDescription className="text-lg font-semibold text-gold">₹30,000 + 1% Success Fee</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="font-semibold text-primary">Maximized Win Probability</p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Everything in Tier 1</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Expert technical proposal drafting</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Financial bid structure review and optimization</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Pre-bid query management</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                    <span className="text-sm">Post-submission follow-up support</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/services" className="w-full" data-testid="link-tier2-details">
                  <Button className="w-full bg-gold text-gold-foreground" data-testid="button-tier2-learn-more">Learn More</Button>
                </Link>
              </CardFooter>
            </Card>
          </div>

          <div className="text-center mt-8">
            <Link href="/case-studies" data-testid="link-success-stories">
              <Button variant="outline" size="lg" data-testid="button-success-stories">
                See Our Success Stories
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-24 bg-background">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="bg-muted/50 rounded-md p-8 lg:p-12">
            <div className="text-center mb-8">
              <p className="text-sm font-semibold text-muted-foreground mb-2">TRUSTED BY LEADING SMEs</p>
              <h3 className="text-2xl font-semibold text-foreground">Successfully Serving Clients Across Industries</h3>
            </div>
            <div className="grid grid-cols-3 lg:grid-cols-6 gap-8 items-center justify-items-center opacity-60">
              <div className="text-center">
                <Award className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">Civil Construction</p>
              </div>
              <div className="text-center">
                <TrendingUp className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">IT Services</p>
              </div>
              <div className="text-center">
                <FileCheck className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">Manufacturing</p>
              </div>
              <div className="text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">Consulting</p>
              </div>
              <div className="text-center">
                <Clock className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">Supply Chain</p>
              </div>
              <div className="text-center">
                <Bell className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                <p className="text-xs font-medium text-muted-foreground">Engineering</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 lg:py-24 bg-gradient-to-br from-gold/10 to-transparent">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
            <div className="lg:col-span-3">
              <Badge className="mb-4 bg-gold text-gold-foreground">Daily Tender Alerts</Badge>
              <h2 className="text-3xl lg:text-4xl font-semibold mb-4 text-foreground">
                Stop Searching. Start Bidding.
              </h2>
              <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                Get your curated daily tender list delivered straight to your inbox. We monitor CPPP and major PSU portals so you can focus on preparing winning bids.
              </p>
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                  <span>Manually curated high-value opportunities</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                  <span>Filtered by industry and tender value</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                  <span>Never miss a deadline again</span>
                </li>
              </ul>
              <Link href="/tender-alerts" data-testid="link-tender-alerts-cta">
                <Button size="lg" className="bg-gold text-gold-foreground" data-testid="button-tender-alerts">
                  Get Daily Tender Alerts
                </Button>
              </Link>
            </div>
            <div className="lg:col-span-2">
              <Card className="hover-elevate">
                <CardHeader>
                  <CardTitle>Pricing</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-3xl font-bold text-foreground" data-testid="text-price-annual">₹15,000<span className="text-base font-normal text-muted-foreground">/year</span></p>
                    <p className="text-sm text-muted-foreground" data-testid="text-price-monthly">or ₹1,500/month</p>
                  </div>
                  <Link href="/tender-alerts" className="block" data-testid="link-subscribe-now">
                    <Button className="w-full bg-primary text-primary-foreground" data-testid="button-subscribe-now">
                      Subscribe Now
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
