import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Award, Target } from "lucide-react";

export default function CaseStudies() {
  const caseStudies = [
    {
      client: "A New Contractor",
      industry: "Civil Construction",
      challenge: "First-time bidder with no prior experience in government tenders. Struggled with understanding EMD/Bid Security filing requirements and CPPP portal navigation. Had all necessary licenses but didn't know how to present them.",
      solution: "Tier 1 Service - Complete document review and portal submission support",
      result: "Successfully awarded a ₹75 Lakh road construction contract on their very first tender submission. Zero technical rejections.",
      icon: Award,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      client: "A Regional SME",
      industry: "IT Services & Software Development",
      challenge: "Multiple failed attempts at state government IT tenders due to weak technical proposals. Had technical capability but couldn't communicate value effectively. Lost 3 consecutive bids despite being qualified.",
      solution: "Tier 2 Service - Full proposal writing with competitive positioning strategy",
      result: "Won a ₹1.2 Crore software development contract with the highest technical score among 12 bidders. Client now has repeat business with the department.",
      icon: TrendingUp,
      color: "text-gold",
      bgColor: "bg-gold/10",
    },
    {
      client: "An Engineering Services Firm",
      industry: "Manufacturing & Supply",
      challenge: "Qualified for a high-value PSU tender but overwhelmed by the 200+ page RFP requirements. Short timeline (15 days) made it impossible to prepare quality response internally while managing daily operations.",
      solution: "Tier 2 Service - Express proposal development with dedicated project manager",
      result: "Awarded ₹2.8 Crore supply contract for electrical equipment. Beat 8 established competitors through superior technical presentation and optimized financial bid.",
      icon: Target,
      color: "text-chart-1",
      bgColor: "bg-chart-1/10",
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-16 lg:py-20 bg-gradient-to-br from-primary/5 to-transparent">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-foreground tracking-tight" data-testid="text-case-studies-headline">
            Our Results Speak for Themselves
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            <span className="font-semibold text-gold">85% of client submissions</span> are technically compliant and proceed to evaluation. Here are real success stories from businesses just like yours.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {caseStudies.map((study, index) => (
              <Card
                key={index}
                className="hover-elevate flex flex-col"
                data-testid={`card-case-study-${index}`}
              >
                <CardHeader>
                  <div className={`mb-4 h-12 w-12 rounded-md ${study.bgColor} flex items-center justify-center`}>
                    <study.icon className={`h-6 w-6 ${study.color}`} />
                  </div>
                  <Badge variant="outline" className="w-fit mb-2">
                    {study.industry}
                  </Badge>
                  <CardTitle className="text-xl" data-testid={`text-case-client-${index}`}>
                    Client: {study.client}
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-1 space-y-6">
                  <div>
                    <h3 className="font-semibold text-sm text-muted-foreground mb-2 uppercase tracking-wide">
                      Challenge
                    </h3>
                    <p className="text-sm text-foreground leading-relaxed" data-testid={`text-case-challenge-${index}`}>
                      {study.challenge}
                    </p>
                  </div>

                  <div>
                    <h3 className="font-semibold text-sm text-muted-foreground mb-2 uppercase tracking-wide">
                      Our Solution
                    </h3>
                    <p className="text-sm font-medium text-primary">
                      {study.solution}
                    </p>
                  </div>

                  <div className="bg-muted/30 rounded-md p-4 border-l-4 border-gold">
                    <h3 className="font-semibold text-sm text-muted-foreground mb-2 uppercase tracking-wide">
                      Result
                    </h3>
                    <p className="text-sm font-semibold text-foreground leading-relaxed" data-testid={`text-case-result-${index}`}>
                      {study.result}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-16 text-center max-w-3xl mx-auto">
            <div className="bg-gold/10 rounded-md p-8 mb-8 border border-gold/20">
              <h2 className="text-3xl font-bold mb-4 text-foreground">
                85% Success Rate
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Our clients experience dramatically higher success rates compared to industry average of 30-40% for first-time bidders. We turn complexity into competitive advantage.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
              <div>
                <p className="text-4xl font-bold text-gold mb-2">200+</p>
                <p className="text-sm text-muted-foreground">Successful Bids</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-gold mb-2">₹50+ Cr</p>
                <p className="text-sm text-muted-foreground">Contract Value Won</p>
              </div>
              <div>
                <p className="text-4xl font-bold text-gold mb-2">100+</p>
                <p className="text-sm text-muted-foreground">Happy Clients</p>
              </div>
            </div>

            <h2 className="text-3xl font-semibold mb-4 text-foreground">
              Ready to Join Our Success Stories?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Let's discuss your tender requirements and create a winning strategy together
            </p>
            <Link href="/contact" data-testid="link-case-studies-cta">
              <Button size="lg" className="bg-gold text-gold-foreground" data-testid="button-get-consultation">
                Get Your Free Consultation
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
