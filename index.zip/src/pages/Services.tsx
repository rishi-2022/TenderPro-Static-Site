import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, X, Minus } from "lucide-react";

export default function Services() {
  return (
    <div className="min-h-screen">
      <section className="relative py-16 lg:py-20 bg-gradient-to-br from-primary/5 to-transparent">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-foreground tracking-tight" data-testid="text-services-headline">
            Professional Tender Consulting Services
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From document compliance to winning proposal strategies, we provide end-to-end support for your tender success
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto mb-16">
            <Card className="hover-elevate">
              <CardHeader>
                <Badge className="w-fit mb-2 bg-primary text-primary-foreground">Tier 1</Badge>
                <CardTitle className="text-2xl lg:text-3xl">Document Review & Filing</CardTitle>
                <CardDescription className="text-xl font-semibold text-gold mt-2">₹15,000 - ₹25,000</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="font-semibold text-lg text-primary mb-4">Compliance Guarantee</p>
                  <p className="text-muted-foreground mb-6">
                    Perfect for businesses that have their documentation ready but need expert verification to ensure 100% compliance with tender requirements.
                  </p>
                </div>
                
                <div>
                  <p className="font-semibold mb-3">What's Included:</p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Complete document organization and checklist verification</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Eligibility cross-check against all tender requirements</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Digital signature integration and validation guidance</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Complete CPPP/GeM portal upload support and submission</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">EMD and bid security format guidance</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Technical specification compliance check</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-primary/5 rounded-md p-4">
                  <p className="text-sm font-semibold mb-1">Best For:</p>
                  <p className="text-sm text-muted-foreground">
                    First-time bidders, small tenders (&lt;₹50L), businesses with in-house teams needing compliance verification
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/contact" className="w-full" data-testid="link-tier1-book">
                  <Button variant="outline" className="w-full" size="lg" data-testid="button-book-tier1">
                    Book Tier 1 Service
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            <Card className="border-2 border-gold hover-elevate relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-gold text-gold-foreground px-6 py-2 text-sm font-semibold">
                MOST POPULAR
              </div>
              <CardHeader className="pt-10">
                <Badge className="w-fit mb-2 bg-gold text-gold-foreground">Tier 2</Badge>
                <CardTitle className="text-2xl lg:text-3xl">Proposal Writing & Strategy</CardTitle>
                <CardDescription className="text-xl font-semibold text-gold mt-2">₹30,000 + 1% Success Fee</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <p className="font-semibold text-lg text-primary mb-4">Maximized Win Probability</p>
                  <p className="text-muted-foreground mb-6">
                    Comprehensive service for businesses serious about winning. We craft compelling proposals and manage the entire bid lifecycle.
                  </p>
                </div>
                
                <div>
                  <p className="font-semibold mb-3">What's Included:</p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm font-semibold">Everything in Tier 1, plus:</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Expert technical proposal drafting with win themes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Financial bid structure review and pricing optimization</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Pre-bid meeting attendance and query management</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Competitive analysis and differentiation strategy</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Post-submission follow-up and clarification support</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Presentation support for technical evaluation (if required)</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gold/10 rounded-md p-4 border border-gold/20">
                  <p className="text-sm font-semibold mb-1">Best For:</p>
                  <p className="text-sm text-muted-foreground">
                    High-value tenders (&gt;₹50L), competitive bids, businesses lacking proposal writing expertise
                  </p>
                </div>
              </CardContent>
              <CardFooter>
                <Link href="/contact" className="w-full" data-testid="link-tier2-book">
                  <Button className="w-full bg-gold text-gold-foreground" size="lg" data-testid="button-book-tier2">
                    Book Tier 2 Service
                  </Button>
                </Link>
              </CardFooter>
            </Card>
          </div>

          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-semibold text-center mb-8 text-foreground">Service Comparison</h2>
            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full" data-testid="table-service-comparison">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-4 font-semibold">Feature</th>
                        <th className="text-center p-4 font-semibold">DIY</th>
                        <th className="text-center p-4 font-semibold">Tier 1</th>
                        <th className="text-center p-4 font-semibold bg-gold/10">Tier 2</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Risk of Technical Rejection</td>
                        <td className="p-4 text-center">
                          <Badge variant="destructive">High</Badge>
                        </td>
                        <td className="p-4 text-center">
                          <Badge className="bg-primary text-primary-foreground">Low</Badge>
                        </td>
                        <td className="p-4 text-center bg-gold/5">
                          <Badge className="bg-gold text-gold-foreground">Very Low</Badge>
                        </td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Document Compliance Check</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><CheckCircle2 className="h-5 w-5 text-primary mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Portal Upload Support</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><CheckCircle2 className="h-5 w-5 text-primary mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Technical Proposal Writing</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Financial Bid Optimization</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><Minus className="h-5 w-5 text-muted-foreground mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Pre-bid Meeting Support</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Post-submission Follow-up</td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center"><X className="h-5 w-5 text-destructive mx-auto" /></td>
                        <td className="p-4 text-center bg-gold/5"><CheckCircle2 className="h-5 w-5 text-gold mx-auto" /></td>
                      </tr>
                      <tr className="hover-elevate">
                        <td className="p-4 font-medium">Time Investment Required</td>
                        <td className="p-4 text-center">
                          <Badge variant="destructive">Very High</Badge>
                        </td>
                        <td className="p-4 text-center">
                          <Badge className="bg-primary text-primary-foreground">Low</Badge>
                        </td>
                        <td className="p-4 text-center bg-gold/5">
                          <Badge className="bg-gold text-gold-foreground">Minimal</Badge>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-16 max-w-3xl mx-auto">
            <h2 className="text-3xl font-semibold mb-4 text-foreground">Ready to Win Your Next Tender?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Book a free consultation to discuss your specific needs and get a customized quote
            </p>
            <Link href="/contact" data-testid="link-services-final-cta">
              <Button size="lg" className="bg-gold text-gold-foreground" data-testid="button-start-winning-bid">
                Start Your Winning Bid Now
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
