import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { CheckCircle2, Bell, TrendingUp, Clock, FileText, ExternalLink } from "lucide-react";

export default function TenderAlerts() {
  const [isAnnual, setIsAnnual] = useState(true);

  const sampleTenders = [
    {
      refNumber: "GEM/2024/B/4567890",
      title: "Supply of IT Hardware and Peripherals",
      organization: "Ministry of Electronics & IT",
      deadline: "15th Feb 2024",
      value: "₹85 Lakhs",
    },
    {
      refNumber: "CPPP/2024/CIV/123456",
      title: "Construction of Administrative Building",
      organization: "Public Works Department, Maharashtra",
      deadline: "20th Feb 2024",
      value: "₹2.5 Crores",
    },
    {
      refNumber: "NTPC/2024/SUP/789012",
      title: "Annual Maintenance Contract for Electrical Systems",
      organization: "NTPC Limited",
      deadline: "25th Feb 2024",
      value: "₹1.2 Crores",
    },
    {
      refNumber: "RITES/2024/CON/345678",
      title: "Project Management Consultancy Services",
      organization: "RITES Limited",
      deadline: "28th Feb 2024",
      value: "₹65 Lakhs",
    },
    {
      refNumber: "ONGC/2024/MFG/901234",
      title: "Manufacturing and Supply of Safety Equipment",
      organization: "Oil and Natural Gas Corporation",
      deadline: "5th Mar 2024",
      value: "₹1.8 Crores",
    },
  ];

  return (
    <div className="min-h-screen">
      <section className="relative py-16 lg:py-20 bg-gradient-to-br from-gold/10 to-transparent">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-gold text-gold-foreground">
            <Bell className="h-3 w-3 mr-1" />
            Daily Tender Alerts
          </Badge>
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-foreground tracking-tight" data-testid="text-alerts-headline">
            Stop Searching. Start Bidding.<br />Your Curated Daily Tender List.
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We monitor CPPP and major PSU portals daily so you don't have to. Only high-value, relevant leads delivered to your inbox.
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-gold/10 flex items-center justify-center">
                  <TrendingUp className="h-6 w-6 text-gold" />
                </div>
                <CardTitle>Manually Curated</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Our experts review every tender to ensure quality. No spam, no irrelevant opportunities.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-gold/10 flex items-center justify-center">
                  <FileText className="h-6 w-6 text-gold" />
                </div>
                <CardTitle>Industry-Specific</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tenders filtered by your industry, location preferences, and budget range.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover-elevate">
              <CardHeader>
                <div className="mx-auto mb-4 h-12 w-12 rounded-md bg-gold/10 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-gold" />
                </div>
                <CardTitle>Never Miss Deadlines</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Receive alerts with plenty of time to prepare quality bids. Early bird advantage.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="max-w-3xl mx-auto">
            <Card className="border-2 border-gold">
              <CardHeader className="text-center">
                <CardTitle className="text-3xl mb-4">Subscription Pricing</CardTitle>
                <div className="flex items-center justify-center gap-4 mb-6">
                  <Label htmlFor="billing-toggle" className={!isAnnual ? "font-semibold" : ""}>
                    Monthly
                  </Label>
                  <Switch
                    id="billing-toggle"
                    checked={isAnnual}
                    onCheckedChange={setIsAnnual}
                    data-testid="switch-billing-toggle"
                  />
                  <Label htmlFor="billing-toggle" className={isAnnual ? "font-semibold" : ""}>
                    Annual <Badge className="ml-2 bg-gold text-gold-foreground">Save 17%</Badge>
                  </Label>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="text-center">
                  <p className="text-5xl font-bold text-foreground mb-2" data-testid="text-subscription-price">
                    {isAnnual ? "₹15,000" : "₹1,500"}
                  </p>
                  <p className="text-muted-foreground">{isAnnual ? "per year" : "per month"}</p>
                  {isAnnual && (
                    <p className="text-sm text-gold mt-2">That's just ₹1,250/month when billed annually</p>
                  )}
                </div>

                <div className="space-y-3">
                  <p className="font-semibold text-center mb-4">What You Get:</p>
                  <ul className="space-y-3">
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Daily curated tender list via email (Monday to Friday)</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Coverage: CPPP, GeM, and 50+ major PSU portals</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Filtered by your industry preferences</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Tender value range customization</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Direct links to tender documents and portals</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Deadline tracking and reminders</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 text-gold mt-0.5 flex-shrink-0" />
                      <span className="text-sm">Cancel anytime (for monthly plans)</span>
                    </li>
                  </ul>
                </div>

                <Link href="/contact" className="block" data-testid="link-subscribe-now">
                  <Button className="w-full bg-gold text-gold-foreground" size="lg" data-testid="button-subscribe-tender-alerts">
                    Subscribe Now
                  </Button>
                </Link>

                <p className="text-xs text-center text-muted-foreground">
                  Secure payment processing. Your subscription will be activated within 24 hours.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="mt-16 max-w-5xl mx-auto">
            <h2 className="text-3xl font-semibold text-center mb-4 text-foreground">Preview: Top Tenders This Week</h2>
            <p className="text-center text-muted-foreground mb-8">
              See the kind of opportunities our subscribers receive daily
            </p>

            <div className="space-y-4">
              {sampleTenders.map((tender, index) => (
                <Card key={index} className="hover-elevate" data-testid={`card-tender-sample-${index}`}>
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-start gap-3 mb-2">
                          <Badge variant="outline" className="text-xs">
                            {tender.refNumber}
                          </Badge>
                          <Badge className="bg-gold text-gold-foreground text-xs">
                            {tender.value}
                          </Badge>
                        </div>
                        <h3 className="font-semibold text-lg mb-1 text-foreground" data-testid={`text-tender-title-${index}`}>
                          {tender.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-2">{tender.organization}</p>
                        <p className="text-sm flex items-center gap-1 text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          Deadline: {tender.deadline}
                        </p>
                      </div>
                      <Button variant="outline" size="sm" className="gap-2" data-testid={`button-view-tender-${index}`}>
                        View Details
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="text-center mt-8">
              <p className="text-muted-foreground mb-4">
                This is just a sample. Subscribers receive 10-20 relevant tenders daily.
              </p>
              <Link href="/contact" data-testid="link-get-started">
                <Button className="bg-primary text-primary-foreground" size="lg" data-testid="button-get-started">
                  Get Started Today
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
