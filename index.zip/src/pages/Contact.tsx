import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { insertConsultationSchema, type InsertConsultation } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Mail, Phone, MapPin, Clock, CheckCircle2 } from "lucide-react";
import { useState } from "react";

export default function Contact() {
  const { toast } = useToast();
  const [isSubmitted, setIsSubmitted] = useState(false);

  const form = useForm<InsertConsultation>({
    resolver: zodResolver(insertConsultationSchema),
    defaultValues: {
      name: "",
      companyName: "",
      email: "",
      phone: "",
      industry: "",
      tenderValue: "",
      deadline: "",
      documentsReady: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: InsertConsultation) => {
      return await apiRequest("POST", "/api/consultations", data);
    },
    onSuccess: () => {
      setIsSubmitted(true);
      toast({
        title: "Consultation Request Received!",
        description: "We'll contact you within 24 hours to discuss your tender requirements.",
      });
      form.reset();
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Please try again or contact us directly via phone or email.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertConsultation) => {
    mutation.mutate(data);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center py-16">
        <div className="max-w-2xl mx-auto px-6 text-center">
          <div className="mb-6 mx-auto h-16 w-16 rounded-full bg-gold/10 flex items-center justify-center">
            <CheckCircle2 className="h-8 w-8 text-gold" />
          </div>
          <h1 className="text-4xl font-bold mb-4 text-foreground">Thank You!</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Your consultation request has been received. Our tender experts will contact you within 24 hours to discuss your requirements.
          </p>
          <div className="space-y-4 text-left bg-muted/30 rounded-md p-6">
            <p className="text-sm text-muted-foreground">
              <span className="font-semibold text-foreground">Next Steps:</span>
            </p>
            <ol className="list-decimal list-inside space-y-2 text-sm text-muted-foreground">
              <li>Our team will review your tender requirements</li>
              <li>We'll prepare a customized quote based on your needs</li>
              <li>Schedule a detailed consultation call to discuss strategy</li>
              <li>Begin work immediately upon agreement</li>
            </ol>
          </div>
          <div className="mt-8">
            <Button
              onClick={() => setIsSubmitted(false)}
              variant="outline"
              data-testid="button-submit-another"
            >
              Submit Another Request
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <section className="relative py-16 lg:py-20 bg-gradient-to-br from-primary/5 to-transparent">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h1 className="text-4xl lg:text-5xl font-bold mb-6 text-foreground tracking-tight" data-testid="text-contact-headline">
            Ready to Win Your Next Tender?
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Book your free bid assessment and get expert guidance on your tender requirements
          </p>
        </div>
      </section>

      <section className="py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <CardTitle className="text-2xl">Consultation Request Form</CardTitle>
                  <CardDescription>
                    Fill out the form below and our tender experts will contact you within 24 hours
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Your Name <span className="text-gold">*</span>
                              </FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="Rajesh Kumar"
                                  {...field}
                                  data-testid="input-name"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="companyName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Company Name <span className="text-gold">*</span>
                              </FormLabel>
                              <FormControl>
                                <Input
                                  placeholder="ABC Enterprises Pvt Ltd"
                                  {...field}
                                  data-testid="input-company"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Email Address <span className="text-gold">*</span>
                              </FormLabel>
                              <FormControl>
                                <Input
                                  type="email"
                                  placeholder="rajesh@abcenterprises.com"
                                  {...field}
                                  data-testid="input-email"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>
                                Phone Number <span className="text-gold">*</span>
                              </FormLabel>
                              <FormControl>
                                <Input
                                  type="tel"
                                  placeholder="+91 98765 43210"
                                  {...field}
                                  data-testid="input-phone"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="industry"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Target Industry / Work Type <span className="text-gold">*</span>
                            </FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              data-testid="select-industry"
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your industry" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="civil">Civil Construction</SelectItem>
                                <SelectItem value="it">IT Services & Software</SelectItem>
                                <SelectItem value="manufacturing">Manufacturing & Supply</SelectItem>
                                <SelectItem value="consulting">Professional Consulting</SelectItem>
                                <SelectItem value="engineering">Engineering Services</SelectItem>
                                <SelectItem value="healthcare">Healthcare & Medical</SelectItem>
                                <SelectItem value="education">Education & Training</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="tenderValue"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>
                              Estimated Tender Value <span className="text-gold">*</span>
                            </FormLabel>
                            <Select
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              data-testid="select-tender-value"
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select tender value range" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="<50L">Less than ₹50 Lakhs</SelectItem>
                                <SelectItem value="50L-1Cr">₹50 Lakhs - ₹1 Crore</SelectItem>
                                <SelectItem value=">1Cr">More than ₹1 Crore</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="deadline"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Tender Deadline (Approximate)</FormLabel>
                            <FormControl>
                              <Input
                                type="date"
                                {...field}
                                data-testid="input-deadline"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="documentsReady"
                        render={({ field }) => (
                          <FormItem className="space-y-3">
                            <FormLabel>
                              Are your documents ready for review? <span className="text-gold">*</span>
                            </FormLabel>
                            <FormControl>
                              <RadioGroup
                                onValueChange={field.onChange}
                                defaultValue={field.value}
                                className="flex flex-col space-y-2"
                                data-testid="radio-documents-ready"
                              >
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="yes" id="yes" />
                                  <Label htmlFor="yes" className="font-normal cursor-pointer">
                                    Yes, all documents are ready
                                  </Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="no" id="no" />
                                  <Label htmlFor="no" className="font-normal cursor-pointer">
                                    No, I need help preparing documents
                                  </Label>
                                </div>
                                <div className="flex items-center space-x-2">
                                  <RadioGroupItem value="partial" id="partial" />
                                  <Label htmlFor="partial" className="font-normal cursor-pointer">
                                    Partially ready
                                  </Label>
                                </div>
                              </RadioGroup>
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <Button
                        type="submit"
                        className="w-full bg-gold hover:bg-gold text-gold-foreground"
                        size="lg"
                        disabled={mutation.isPending}
                        data-testid="button-submit-consultation"
                      >
                        {mutation.isPending ? "Submitting..." : "Request Free Consultation"}
                      </Button>

                      <p className="text-xs text-center text-muted-foreground">
                        By submitting this form, you agree to our Terms of Service and Privacy Policy
                      </p>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Contact Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-3">
                    <Mail className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-sm text-foreground">Email</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-email">
                        info@tenderwin.in
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-sm text-foreground">Phone</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-phone">
                        +91 98765 43210
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-sm text-foreground">Address</p>
                      <p className="text-sm text-muted-foreground" data-testid="text-address">
                        Mumbai, Maharashtra, India
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Clock className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-sm text-foreground">Business Hours</p>
                      <p className="text-sm text-muted-foreground">
                        Monday - Friday: 9:00 AM - 6:00 PM IST<br />
                        Saturday: 10:00 AM - 2:00 PM IST
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-muted/30">
                <CardHeader>
                  <CardTitle className="text-lg">What Happens Next?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-gold text-gold-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
                      1
                    </div>
                    <p className="text-sm text-muted-foreground">
                      We review your tender requirements within 4 hours
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-gold text-gold-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
                      2
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Our expert calls you to discuss the tender and provide a customized quote
                    </p>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="h-6 w-6 rounded-full bg-gold text-gold-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
                      3
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Upon agreement, we begin work immediately to meet your deadline
                    </p>
                  </div>
                </CardContent>
              </Card>

              <div className="bg-gradient-to-br from-primary to-primary/80 rounded-md p-6 text-white">
                <h3 className="font-semibold mb-2">Emergency Tender Support?</h3>
                <p className="text-sm text-white/90 mb-4">
                  If your deadline is less than 48 hours, call us directly for immediate assistance.
                </p>
                <Button variant="outline" className="w-full bg-white text-primary" data-testid="button-call-emergency">
                  Call Now: +91 98765 43210
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
