import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import Home from "@/pages/Home";
import Services from "@/pages/Services";
import TenderAlerts from "@/pages/TenderAlerts";
import CaseStudies from "@/pages/CaseStudies";
import Contact from "@/pages/Contact";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/services" component={Services} />
      <Route path="/tender-alerts" component={TenderAlerts} />
      <Route path="/case-studies" component={CaseStudies} />
      <Route path="/contact" component={Contact} />
      <Route path="/disclaimer" component={() => <LegalPage title="Disclaimer" />} />
      <Route path="/terms" component={() => <LegalPage title="Terms of Service" />} />
      <Route path="/privacy" component={() => <LegalPage title="Privacy Policy" />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function LegalPage({ title }: { title: string }) {
  return (
    <div className="min-h-screen py-16">
      <div className="max-w-4xl mx-auto px-6 lg:px-8">
        <h1 className="text-4xl font-bold mb-8 text-foreground">{title}</h1>
        <div className="prose prose-sm max-w-none space-y-4 text-muted-foreground">
          <p>This is a placeholder page for {title}. Legal content will be added here.</p>
        </div>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="flex flex-col min-h-screen">
          <Navigation />
          <main className="flex-1">
            <Router />
          </main>
          <Footer />
        </div>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
